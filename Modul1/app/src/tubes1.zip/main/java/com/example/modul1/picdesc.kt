package com.example.modul1
import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.FragmentTransaction
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class picdesc : Fragment() {

    private lateinit var nameTextView: TextView
    private lateinit var dateTextView: TextView
    private lateinit var descriptionTextView: TextView
    private lateinit var storyTextView: TextView
    private lateinit var editButton: Button
    private var defaultFileName: String? = null  // Add this variable to store the default file name
    val pictureName = MainActivity.PictureNameGenerator.generatePictureName()


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_picdesc, container, false)

        nameTextView = view.findViewById(R.id.namapic)
        dateTextView = view.findViewById(R.id.puttanggal)
        descriptionTextView = view.findViewById(R.id.putdesc)
        storyTextView = view.findViewById(R.id.putstory)
        editButton = view.findViewById(R.id.Editbtn)
        defaultFileName = arguments?.getString("photoName", "")

        // Set your sample data here
        nameTextView.text = arguments?.getString("defaultFileName", "")
        // Set other TextViews accordingly

        // Set an onClickListener for the Edit button to open the EditPicDescFragment
        editButton.setOnClickListener {
            openEditPicDescFragment()
        }

        val photoName = arguments?.getString("photoName", "")
        val editedDescription = getEditedDataFromSharedPreferences("$defaultFileName-editedDescription", "")
        val editedStory = getEditedDataFromSharedPreferences("$defaultFileName-editedStory", "")

        // Use the retrieved data as needed
        descriptionTextView.text = editedDescription
        storyTextView.text = editedStory

        setCurrentDate()
        return view
    }
    private fun setCurrentDate() {
        val currentDate = getCurrentDate()
        dateTextView.text = currentDate
    }

    private fun getCurrentDate(): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val currentDate = dateFormat.format(Date())
        return currentDate
    }


    private fun getEditedDataFromSharedPreferences(key: String, defaultValue: String): String {
        val sharedPreferences = requireContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        return sharedPreferences.getString(key, defaultValue) ?: defaultValue
    }

    private fun openEditPicDescFragment() {
        val editPicDescFragment = Editpicdesc()

        // Pass data to EditPicDescFragment
        val bundle = Bundle()
        bundle.putString("name", nameTextView.text.toString())
        bundle.putString("date", dateTextView.text.toString())
        bundle.putString("description", descriptionTextView.text.toString())
        bundle.putString("story", storyTextView.text.toString())
        editPicDescFragment.arguments = bundle

        val fragmentTransaction: FragmentTransaction = requireActivity().supportFragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.fragment_container, editPicDescFragment, "editPicDescTag")
        fragmentTransaction.addToBackStack(null)
        fragmentTransaction.commitAllowingStateLoss()

        Log.d("Editpicdesc", "Replacing fragment with tag: $tag")
    }


    fun updateData(name: String, file: String, date: String, description: String, story: String) {
        // Update your TextViews with the new data
        nameTextView.text = name
        dateTextView.text = date
        descriptionTextView.text = description
        storyTextView.text = story
        defaultFileName = file.split("/").lastOrNull() ?: ""
        Log.d("picdesc", "updateData called with: $name, $file, $date, $description, $story")
    }

}