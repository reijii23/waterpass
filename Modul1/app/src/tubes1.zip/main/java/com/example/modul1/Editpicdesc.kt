package com.example.modul1

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.fragment.app.Fragment

class Editpicdesc: Fragment() {

    interface EditPicDescView {
        fun getEditedDescription(): String
        fun getEditedStory(): String
    }

    private lateinit var nameTextView: TextView
    private lateinit var dateTextView: TextView
    private lateinit var descriptionEditText: EditText
    private lateinit var storyEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var editListener: OnEditDataListener



    override fun onAttach(context: Context) {
        super.onAttach(context)
        try {
            editListener = context as OnEditDataListener
        } catch (e: ClassCastException) {
            throw ClassCastException("$context must implement OnEditDataListener")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_editpicdesc, container, false)

        nameTextView = view.findViewById(R.id.namapic)
        dateTextView = view.findViewById(R.id.puttanggal)
        descriptionEditText = view.findViewById(R.id.putdesc)
        storyEditText = view.findViewById(R.id.putstory)
        saveButton = view.findViewById(R.id.Savebtn)

        // Retrieve data from arguments
        val name = arguments?.getString("name", "")
        val file = arguments?.getString("file", "")
        val date = arguments?.getString("date", "")
        val description = arguments?.getString("description", "")
        val story = arguments?.getString("story", "")

        // Set data to views
        nameTextView.text = name
        dateTextView.text = date
        descriptionEditText.setText(description)
        storyEditText.setText(story)

        // Set an onClickListener for the Save button to save the edited data
        saveButton.setOnClickListener {
            saveEditedData()
        }

        return view
    }

    // Inside the Editpicdesc fragment in saveEditedData method
    private fun saveEditedData() {
        // Get the edited data
        val editedDescription = descriptionEditText.text.toString()
        val editedStory = storyEditText.text.toString()

        // Retrieve the photo name from arguments
        val photoName = arguments?.getString("name", "")

        // Save the edited data in SharedPreferences with a unique key using the photo name
        saveDataInSharedPreferences(photoName, editedDescription, editedStory)

        // Close the fragment
        requireActivity().supportFragmentManager.popBackStack()
    }

    fun getEditedDescription(): String {
        return descriptionEditText.text.toString()
    }

    fun getEditedStory(): String {
        return storyEditText.text.toString()
    }

    private fun saveDataInSharedPreferences(photoName: String?, description: String, story: String) {
        if (!photoName.isNullOrEmpty()) {
            val sharedPreferences = requireContext().getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
            val editor = sharedPreferences.edit()

            // Use the photo name as part of the unique keys
            editor.putString("$photoName-editedDescription", description)
            editor.putString("$photoName-editedStory", story)

            // Commit the changes
            editor.apply()
        }
    }

    interface OnEditDataListener {
        fun onSaveEditedData(
            name: String,
            file: String,
            date: String,
            description: String,
            story: String
        )
    }
}