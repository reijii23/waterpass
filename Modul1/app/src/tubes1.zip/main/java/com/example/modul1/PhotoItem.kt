package com.example.modul1

import android.net.Uri

data class PhotoItem(val name: String, val description: String, val imageResourceId: Int, val imageUri: Uri?)
