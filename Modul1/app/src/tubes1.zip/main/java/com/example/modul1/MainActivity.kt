package com.example.modul1

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.ImageView
import android.widget.ListView
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.drawerlayout.widget.DrawerLayout
import com.google.android.material.navigation.NavigationView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.widget.Toolbar
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import com.example.modul1.PhotoItem
import com.example.modul1.PhotoItemAdapter
import com.example.modul1.picdesc
import com.example.modul1.R
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class MainActivity : AppCompatActivity(), Editpicdesc.OnEditDataListener {
    private val items: MutableList<PhotoItem> = mutableListOf()
    private lateinit var btncam: Button
    private lateinit var image: ImageView
    private var imageUri: Uri? = null
    private lateinit var intentLauncher: ActivityResultLauncher<Intent>
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var navigationView: NavigationView
    private lateinit var listView: ListView
    private lateinit var photoItemAdapter: PhotoItemAdapter

    companion object {
        private const val REQUEST_IMAGE_CAPTURE = 1
    }

    object PictureNameGenerator {
        private var pictureCounter = 0

        fun generatePictureName(): String {
            val pictureName = "picture_$pictureCounter.jpg"
            pictureCounter++
            return pictureName
        }
    }


    private val resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            handleCapturedImage()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.nav_menu, menu)
        return true
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        photoItemAdapter = PhotoItemAdapter(this, items)
        listView = findViewById(R.id.listView)
        listView.adapter = photoItemAdapter
        listView.setOnItemClickListener { _, _, position, _ ->
            val selectedPhoto = items[position]
            openPicDescFragment(selectedPhoto)
        }

        drawerLayout = findViewById(R.id.drawerLayout)
        navigationView = findViewById(R.id.navigationView)

        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        val actionBar = supportActionBar
        actionBar?.setDisplayHomeAsUpEnabled(true)
        actionBar?.setHomeButtonEnabled(true)

        val drawerToggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer
        )

        drawerLayout.addDrawerListener(drawerToggle)
        drawerToggle.syncState()

        navigationView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.menu_take_picture -> {
                    openCamera()
                    drawerLayout.closeDrawers()  // Close the drawer after handling the click
                    true
                }
                R.id.menu_exit -> {
                    finish()
                    true
                }
                else -> false
            }
        }
        btncam = findViewById(R.id.opencambtn)
        image = findViewById(R.id.image2)

        intentLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                image.setImageURI(imageUri)
            }
        }

        btncam.setOnClickListener {
            openCamera()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_take_picture -> {
                openCamera()
                return true
            }
            R.id.menu_exit -> {
                finish()
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }


    private fun openPicDescFragment(photoItem: PhotoItem) {
        val fragment = picdesc()
        val bundle = Bundle().apply {
            putString("photoName", photoItem.name)  // Use the photoItem's name as the photoName
            putString("defaultFileName", photoItem.name )  // Pass the default file name
            // Add other data you want to pass
        }
        fragment.arguments = bundle

        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment, "picdescTag")
            .addToBackStack(null)
            .commit()
    }


    private fun openCamera() {
        // Create a directory to store the images
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        val imageFile = File.createTempFile(
            "JPEG_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())}_",
            ".jpg",
            storageDir
        )

        // Save the file path for use with ACTION_VIEW intents
        imageUri = FileProvider.getUriForFile(this, "com.example.tubes01.fileprovider", imageFile)

        // Create the camera intent
        val takePictureIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri)
        resultLauncher.launch(takePictureIntent)
    }

    private fun handleCapturedImage() {
        val defaultFileName = imageUri?.lastPathSegment ?: ""
        val newItem = PhotoItem(defaultFileName, "Description for the new photo", getImageResourceIdForNewPhoto(), imageUri)
        items.add(newItem)
        photoItemAdapter.notifyDataSetChanged()
    }



    private fun getImageResourceIdForNewPhoto(): Int {
        return R.drawable.default_image
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQUEST_IMAGE_CAPTURE && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            openCamera()
        }
    }

    override fun onSaveEditedData(name: String, file: String, date: String, description: String, story: String) {
        Log.d("MainActivity", "Received edited data: name=$name, description=$description, story=$story")
        // Use the default file name as the key
        val defaultFileName = file.split("/").lastOrNull() ?: ""

        // Save the edited data in SharedPreferences
        saveEditedDataToSharedPreferences("$defaultFileName-editedDescription", description)
        saveEditedDataToSharedPreferences("$defaultFileName-editedStory", story)

        // You need to find your PicDescFragment instance and update its data
        val picDescFragment = supportFragmentManager.findFragmentByTag("picdescTag") as? picdesc
        picDescFragment?.updateData(name, file, date, description, story)
    }

    private fun saveEditedDataToSharedPreferences(key: String, value: String) {
        val sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString(key, value)
        editor.apply()
    }

    private fun getEditedDataFromSharedPreferences(key: String, defaultValue: String): String {
        val sharedPreferences = getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)
        return sharedPreferences.getString(key, defaultValue) ?: defaultValue
    }


}