package com.example.modul1

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class PhotoItemAdapter(private val context: Context, private val items: MutableList<PhotoItem>) : BaseAdapter() {

    fun addItem(item: PhotoItem) {
        items.add(item)
        notifyDataSetChanged()
    }

    override fun getCount(): Int {
        return items.size
    }

    override fun getItem(position: Int): Any {
        return items[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View
        val viewHolder: ViewHolder

        if (convertView == null) {
            view = LayoutInflater.from(context).inflate(R.layout.custom_list_item, parent, false)
            viewHolder = ViewHolder(view)
            view.tag = viewHolder
        } else {
            view = convertView
            viewHolder = view.tag as ViewHolder
        }

        val item = getItem(position) as PhotoItem

        viewHolder.nameTextView.text = item.name
        viewHolder.descriptionTextView.text = item.description

        // Load and set the actual image from the URI
        if (item.imageUri != null) {
            viewHolder.imageView.setImageURI(item.imageUri)
        } else {
            // Use the default image if the URI is null
            viewHolder.imageView.setImageResource(item.imageResourceId)
        }

        return view
    }


    private class ViewHolder(view: View) {
        val nameTextView: TextView = view.findViewById(R.id.nameTextView)
        val descriptionTextView: TextView = view.findViewById(R.id.descriptionTextView)
        val imageView: ImageView = view.findViewById(R.id.image2)
    }
}