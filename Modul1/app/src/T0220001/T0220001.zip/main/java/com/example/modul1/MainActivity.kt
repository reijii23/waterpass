package com.example.modul1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import android.widget.Button
import android.widget.TextView
import android.widget.ImageButton
import android.widget.LinearLayout
import com.example.modul1.ui.theme.Modul1Theme
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ListView
import java.util.LinkedList


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layouts)

        val foodItems = mutableListOf<FoodItem>()
        val adapter = FoodListAdapter(this)
        adapter.initList(foodItems)

        val titles = findViewById<ListView>(R.id.listView)
        titles.adapter = adapter

        val addButton = findViewById<Button>(R.id.addButton)

        addButton.setOnClickListener {
            val titleEditText = findViewById<EditText>(R.id.title)
            val detailEditText = findViewById<EditText>(R.id.detail)

            val title = titleEditText.text.toString()
            val detail = detailEditText.text.toString()

            if (title.isNotEmpty() && detail.isNotEmpty()) {
                val newFoodItem = FoodItem(title, detail)
                foodItems.add(newFoodItem)
                adapter.initList(foodItems)

                titleEditText.text.clear()
                detailEditText.text.clear()
            }
        }
    }
}

data class FoodItem(val title: String, val details: String, var isFavourite: Boolean = false)

class FoodListAdapter(private val activity: MainActivity) : BaseAdapter() {
    private val foodItems: MutableList<FoodItem> = mutableListOf()

    fun initList(foodItems: List<FoodItem>) {
        this.foodItems.clear()
        this.foodItems.addAll(foodItems)
        notifyDataSetChanged()
    }

    override fun getCount(): Int {
        return foodItems.size
    }

    override fun getItem(i: Int): FoodItem {
        return foodItems[i]
    }

    override fun getItemId(i: Int): Long {
        return i.toLong()
    }

    fun removeItem(i: Int) {
        if (i >= 0 && i < foodItems.size) {
            foodItems.remove(foodItems.get(i))
            notifyDataSetChanged()
        }
    }

    override fun getView(i: Int, view: View?, parent: ViewGroup): View? {
        var view:View? = view
        val viewHolder: ViewHolder

        if (view == null) {
            view = activity.layoutInflater.inflate(R.layout.item_list_food, null)
            viewHolder = ViewHolder()
            viewHolder.titles = view.findViewById(R.id.titles)
            viewHolder.details = view.findViewById(R.id.details)
            viewHolder.starButton = view.findViewById(R.id.star)
            viewHolder.trashButton = view.findViewById(R.id.trash)
            viewHolder.starrableLayout = view.findViewById(R.id.starrable)
            view.tag = viewHolder
        } else {
            viewHolder = view.tag as ViewHolder
        }

        val foodItem = getItem(i)
        viewHolder.titles.text = foodItem.title
        viewHolder.details.text = foodItem.details

        viewHolder.starButton.setImageResource(
            if (foodItem.isFavourite) android.R.drawable.btn_star_big_on
            else android.R.drawable.btn_star_big_off
        )

        viewHolder.trashButton.setOnClickListener {
            removeItem(i)
        }

        viewHolder.starrableLayout.setOnClickListener {
            foodItem.isFavourite = !foodItem.isFavourite
            viewHolder.starButton.setImageResource(
                if (foodItem.isFavourite) android.R.drawable.btn_star_big_on
                else android.R.drawable.btn_star_big_off
            )
        }

        viewHolder.starButton.setOnClickListener {
            foodItem.isFavourite = !foodItem.isFavourite
            viewHolder.starButton.setImageResource(
                if (foodItem.isFavourite) android.R.drawable.btn_star_big_on
                else android.R.drawable.btn_star_big_off
            )
        }
        return view
    }

    private class ViewHolder {
        lateinit var titles: TextView
        lateinit var details: TextView
        lateinit var starButton: ImageButton
        lateinit var trashButton: ImageButton
        lateinit var starrableLayout: LinearLayout
    }
}
