package com.example.modul1
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.widget.Toast

class PaintCanvas(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {

    private lateinit var mBitmap: Bitmap
    private lateinit var mCanvas: Canvas
    private lateinit var mDetector: GestureDetector
    private val start = PointF()
    private lateinit var strokePaint: Paint
    private var canvasInitiated = false

    init {
        initPaint()
        initGestureDetector()
    }

    private fun initPaint() {
        strokePaint = Paint().apply {
            color = Color.BLACK
            strokeWidth = 3f
            style = Paint.Style.STROKE
        }
    }

    private fun initGestureDetector() {
        mDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                start.set(e.x, e.y)
                return true
            }

            override fun onScroll(
                e1: MotionEvent?,
                e2: MotionEvent,
                distanceX: Float,
                distanceY: Float
            ): Boolean {
                if (canvasInitiated) {
                    drawPath(e2.x, e2.y)
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                toggleStrokeWidth()
                showStrokeWidthToast()
            }
        })
    }

    private fun toggleStrokeWidth() {
        val currentStrokeWidth = strokePaint.strokeWidth
        strokePaint.strokeWidth = if (currentStrokeWidth == 3f) 20f else 3f
    }

    private fun showStrokeWidthToast() {
        val currentStrokeWidth = strokePaint.strokeWidth
        Toast.makeText(context, "Stroke Width: $currentStrokeWidth", Toast.LENGTH_SHORT).show()
    }

    fun drawPath(x: Float, y: Float) {
        val path = Path()
        path.moveTo(start.x, start.y)
        path.lineTo(x, y)
        mCanvas.drawPath(path, strokePaint)
        start.set(x, y)
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        mBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        mCanvas = Canvas(mBitmap)
        canvasInitiated = true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (canvasInitiated) {
            canvas.drawBitmap(mBitmap, 0f, 0f, null)
        }
    }

    fun setCanvasColor(color: Int) {
        setBackgroundColor(color)
    }

    fun setStrokeColor(color: Int) {
        strokePaint = Paint().apply {
            this.color = color
            strokeWidth = strokePaint.strokeWidth
            style = Paint.Style.STROKE
        }
        invalidate()
    }

    fun resetCanvas() {
        if (canvasInitiated) {
            mCanvas.drawColor(Color.WHITE)
            invalidate()
        }
    }

    fun initiateCanvas() {
        canvasInitiated = true
        invalidate()
    }

    fun isNewCanvas(): Boolean {
        return !canvasInitiated
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        mDetector.onTouchEvent(event)
        return true
    }
}
