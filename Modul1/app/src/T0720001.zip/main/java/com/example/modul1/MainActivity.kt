package com.example.modul1

import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.os.Bundle
import android.view.GestureDetector
import android.view.MotionEvent
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GestureDetectorCompat

class MainActivity : AppCompatActivity() {

    private lateinit var mCanvas: PaintCanvas
    private lateinit var mDetector: GestureDetectorCompat
    private lateinit var start: PointF
    private lateinit var strokePaint: Paint
    private var canvasInitiated = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mCanvas = findViewById(R.id.paintCanvas)
        mDetector = GestureDetectorCompat(this, MyGestureListener())
        start = PointF(0f, 0f)
        strokePaint = Paint().apply {
            color = Color.BLACK
            strokeWidth = 3f
            style = Paint.Style.STROKE
        }

        val btnNew: Button = findViewById(R.id.btnNew)
        val btnBlack: Button = findViewById(R.id.btnBlack)
        val btnRed: Button = findViewById(R.id.btnRed)
        val btnGreen: Button = findViewById(R.id.btnGreen)
        val btnBlue: Button = findViewById(R.id.btnBlue)

        btnNew.setOnClickListener {
            if (btnNew.text == "New") {
                initiateCanvas()
                btnNew.text = "Reset"
            } else {
                mCanvas.resetCanvas()
                resetPaint()
            }
        }

        btnBlack.setOnClickListener { mCanvas.setStrokeColor(Color.BLACK) }
        btnRed.setOnClickListener { mCanvas.setStrokeColor(Color.RED) }
        btnGreen.setOnClickListener { mCanvas.setStrokeColor(Color.GREEN) }
        btnBlue.setOnClickListener { mCanvas.setStrokeColor(Color.BLUE) }
    }


    private fun initiateCanvas() {
        mCanvas.initiateCanvas()
        canvasInitiated = true
    }

    private fun resetPaint() {
        strokePaint.color = Color.BLACK
        strokePaint.strokeWidth = 3f
    }

    private fun setStrokeColor(color: Int) {
        strokePaint.color = color
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        mDetector.onTouchEvent(event)
        return true
    }

    internal inner class MyGestureListener : GestureDetector.SimpleOnGestureListener() {

        override fun onDown(e: MotionEvent): Boolean {
            start.set(e.x, e.y)
            return true
        }

        override fun onScroll(
            e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float
        ): Boolean {
            if (canvasInitiated) {
                mCanvas.drawPath(start.x, start.y)
                start.set(e2.x, e2.y)
            }
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            if (strokePaint.strokeWidth == 3f) {
                strokePaint.strokeWidth = 20f
                showToast("Stroke Width: 20")
            } else {
                strokePaint.strokeWidth = 3f
                showToast("Stroke Width: 3")
            }
        }
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
