package com.example.modul1

import android.os.Bundle
import androidx.activity.ComponentActivity
//import androidx.activity.compose.setContent
import android.widget.Button
import android.widget.TextView
import android.widget.ImageButton
import android.widget.LinearLayout
import com.example.modul1.ui.theme.Modul1Theme
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import java.util.LinkedList
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileWriter
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var penyimpanNilai: PenyimpanNilaiDisplay

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        penyimpanNilai = PenyimpanNilaiDisplay(this)

        val (barang, harga, keterangan) = penyimpanNilai.getBarang()
        findViewById<EditText>(R.id.barang).setText(barang)
        findViewById<EditText>(R.id.harga).setText(harga)
        findViewById<EditText>(R.id.keterangan).setText(keterangan)

        val addButton = findViewById<Button>(R.id.add)
        addButton.setOnClickListener {
            val barangEditText = findViewById<EditText>(R.id.barang)
            val hargaEditText = findViewById<EditText>(R.id.harga)
            val keteranganEditText = findViewById<EditText>(R.id.keterangan)

            val barang = barangEditText.text.toString()
            val harga = hargaEditText.text.toString()
            val keterangan = keteranganEditText.text.toString()

            penyimpanNilai.saveBarang(barang, harga, keterangan)

            saveToTextFile("$barang $harga $keterangan")

            barangEditText.text.clear()
            hargaEditText.text.clear()
            keteranganEditText.text.clear()
        }
    }

    override fun onPause() {
        super.onPause()
        val barang = findViewById<EditText>(R.id.barang).text.toString()
        val harga = findViewById<EditText>(R.id.harga).text.toString()
        val keterangan = findViewById<EditText>(R.id.keterangan).text.toString()
        penyimpanNilai.saveBarang(barang, harga, keterangan)
    }

    override fun onResume() {
        super.onResume()
        val (barang, harga, keterangan) = penyimpanNilai.getBarang()
        findViewById<EditText>(R.id.barang).setText(barang)
        findViewById<EditText>(R.id.harga).setText(harga)
        findViewById<EditText>(R.id.keterangan).setText(keterangan)
    }

    private fun saveToTextFile(data: String) {
        try {
            val fileName = "pembelian.txt"
            val file = File(filesDir, fileName)
            val writer = FileWriter(file, true)

            writer.append(data)
            writer.append("\n")

            writer.close()
            Toast.makeText(this, "Data saved to $fileName", Toast.LENGTH_SHORT).show()
        } catch (e: IOException) {
            e.printStackTrace()
        }
    }
}
