package com.example.modul1

import android.content.Context

class PenyimpanNilaiDisplay(context: Context) {

    private val sharedPreferences = context.getSharedPreferences("MyPrefs", Context.MODE_PRIVATE)

    fun saveBarang(barang: String, harga: String, keterangan: String) {
        val editor = sharedPreferences.edit()
        editor.putString("barang", barang)
        editor.putString("harga", harga)
        editor.putString("keterangan", keterangan)
        editor.apply()
    }

    fun getBarang(): Triple<String?, String?, String?> {
        val barang = sharedPreferences.getString("barang", null)
        val harga = sharedPreferences.getString("harga", null)
        val keterangan = sharedPreferences.getString("keterangan", null)
        return Triple(barang, harga, keterangan)
    }
}
