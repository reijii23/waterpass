package com.example.modul1

import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity(), OnPortfolioAddedListener {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.fragment_container,MainFragment())
        fragmentTransaction.commit()
    }
    override fun onPortfolioAdded(portfolioData: PortfolioData) {
        val fragmentManager = supportFragmentManager
        val daftarPortfolioFragment = fragmentManager.findFragmentByTag("daftar_portfolio") as? daftar_portfolio
        if (daftarPortfolioFragment != null) {
            daftarPortfolioFragment.addPortfolio(portfolioData)
        }
    }

}
