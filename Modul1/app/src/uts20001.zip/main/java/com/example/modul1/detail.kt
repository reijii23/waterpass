package com.example.modul1

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView

class detail : Fragment() {
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val namaDepan = arguments?.getString("namaDepan")
        val namaBelakang = arguments?.getString("namaBelakang")
        val nomorHP = arguments?.getString("nomorHP")

        val namaTextView = view.findViewById<TextView>(R.id.nama)
        val nomorTextView = view.findViewById<TextView>(R.id.nomor)

        namaTextView.text = "$namaDepan $namaBelakang"
        nomorTextView.text = nomorHP
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_detail, container, false)

    }

}

