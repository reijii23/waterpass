package com.example.modul1

data class PortfolioData(val leftText: String, val rightText: String)
