package com.example.modul1

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction

class pendaftaran : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_pendaftaran, container, false)

        val namadepan = view.findViewById<EditText>(R.id.namadepan)
        val namabelakang = view.findViewById<EditText>(R.id.namabelakang)
        val nohp = view.findViewById<EditText>(R.id.hp)
        val lanjut = view.findViewById<Button>(R.id.lanjut)

        lanjut.setOnClickListener {
            val namaDepan = namadepan.text.toString()
            val namaBelakang = namabelakang.text.toString()
            val nomorHP = nohp.text.toString()
            val bundle = Bundle()
            bundle.putString("namaDepan", namaDepan)
            bundle.putString("namaBelakang", namaBelakang)
            bundle.putString("nomorHP", nomorHP)

            val fragmentManager: FragmentManager = requireActivity().supportFragmentManager
            val transaction: FragmentTransaction = fragmentManager.beginTransaction()

            transaction.remove(this)

            val daftar_portfolio = daftar_portfolio()
            daftar_portfolio.arguments = bundle
            transaction.replace(R.id.fragment_container, daftar_portfolio)
            transaction.addToBackStack(null)

            val detail = detail()
            detail.arguments = bundle
            transaction.commit()
        }

        return view
    }
}
