package com.example.modul1
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ListView
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction

class daftar_portfolio: Fragment() {
    private var portfolioListView: ListView? = null
    private val portfolioDataList = mutableListOf<PortfolioData>()
    private lateinit var sharedPreferences: SharedPreferences

    override fun onAttach(context: Context) {
        super.onAttach(context)
        sharedPreferences = context.getSharedPreferences("portfolio_data", Context.MODE_PRIVATE)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_daftar_portfolio, container, false)

        val add = view.findViewById<Button>(R.id.add)
        val daftar = view.findViewById<Button>(R.id.daftar)
        portfolioListView = view.findViewById<ListView>(R.id.lv)
        val portfolioAdapter = PortfolioAdapter(requireContext(), portfolioDataList)
        portfolioListView?.adapter = portfolioAdapter

        add.setOnClickListener {
            val fragmentManager: FragmentManager = requireActivity().supportFragmentManager
            val transaction: FragmentTransaction = fragmentManager.beginTransaction()

            transaction.remove(this)

            val tambah_portfolio = tambah_portfolio()
            transaction.replace(R.id.fragment_container, tambah_portfolio, "tambah_portfolio")
            transaction.addToBackStack(null)
            transaction.commit()
        }

        daftar.setOnClickListener{
            val fragmentManager: FragmentManager = requireActivity().supportFragmentManager
            val transaction: FragmentTransaction = fragmentManager.beginTransaction()

            transaction.remove(this)

            val utama = MainFragment()
            transaction.replace(R.id.fragment_container, utama, "utama")
            transaction.addToBackStack(null)
            transaction.commit()
        }

        return view
    }
    fun onPortfolioAdded(portfolioData: PortfolioData) {
        addPortfolio(portfolioData)
    }

    fun addPortfolio(newItem: PortfolioData) {
        portfolioDataList.add(newItem)
        val adapter = portfolioListView?.adapter as PortfolioAdapter
        adapter.notifyDataSetChanged()
    }
}


