package com.example.modul1

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction

class tambah_portfolio : Fragment() {
    private var onPortfolioAddedListener: OnPortfolioAddedListener? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnPortfolioAddedListener) {
            onPortfolioAddedListener = context
        } else {
            throw RuntimeException("$context must implement OnPortfolioAddedListener")
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_tambah_portfolio, container, false)

        val namaEditText = view.findViewById<EditText>(R.id.namaport)
        val linkEditText = view.findViewById<EditText>(R.id.linkport)
        val lanjutButton = view.findViewById<Button>(R.id.lanjut)

        lanjutButton.setOnClickListener {
            val nama = namaEditText.text.toString()
            val link = linkEditText.text.toString()

            val newPortfolio = PortfolioData(nama, link)

            onPortfolioAddedListener?.onPortfolioAdded(newPortfolio)

            val fragmentManager: FragmentManager = requireActivity().supportFragmentManager
            val transaction: FragmentTransaction = fragmentManager.beginTransaction()
            transaction.remove(this)

            val daftar_portfolio = daftar_portfolio()
            transaction.replace(R.id.fragment_container, daftar_portfolio, "daftar_portfolio")
            transaction.addToBackStack(null)
            transaction.commit()
        }

        return view
    }
}
class PortfolioAdapter(private val context: Context, private val data: MutableList<PortfolioData>) : BaseAdapter() {
    override fun getCount(): Int {
        return data.size
    }

    override fun getItem(position: Int): Any {
        return data[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View
        val viewHolder: ViewHolder

        if (convertView == null) {
            view = LayoutInflater.from(context).inflate(R.layout.itemlistview, parent, false)
            viewHolder = ViewHolder(view)
            view.tag = viewHolder
        } else {
            view = convertView
            viewHolder = view.tag as ViewHolder
        }

        val portfolioItem = getItem(position) as PortfolioData

        viewHolder.textViewLeft.text = portfolioItem.leftText
        viewHolder.textViewRight.text = portfolioItem.rightText

        return view
    }

    fun addPortfolio(newItem: PortfolioData) {
        data.add(newItem)
        notifyDataSetChanged()
    }

    private class ViewHolder(view: View) {
        val textViewLeft = view.findViewById<TextView>(R.id.namaport)
        val textViewRight = view.findViewById<TextView>(R.id.linkport)
    }
}

interface OnPortfolioAddedListener {
    fun onPortfolioAdded(portfolioData: PortfolioData)
}


