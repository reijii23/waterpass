package com.example.modul1

import android.widget.Button
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction

class MainFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_utama, container, false)

        return view
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val buttonDaftar = view.findViewById<Button>(R.id.buttonDaftar)
        val buttonDetail = view.findViewById<Button>(R.id.buttonDetail)

        buttonDaftar.setOnClickListener {
            val fragmentManager: FragmentManager = requireActivity().supportFragmentManager
            val transaction: FragmentTransaction = fragmentManager.beginTransaction()

            transaction.remove(this)

            val pendaftaran = pendaftaran()
            transaction.replace(R.id.fragment_container, pendaftaran)
            transaction.addToBackStack(null)
            transaction.commit()
        }

        buttonDetail.setOnClickListener {
            val fragmentManager: FragmentManager = requireActivity().supportFragmentManager
            val transaction: FragmentTransaction = fragmentManager.beginTransaction()

            transaction.remove(this)

            val detail = detail()
            transaction.replace(R.id.fragment_container, detail)
            transaction.addToBackStack(null)
            transaction.commit()
        }

    }
}
