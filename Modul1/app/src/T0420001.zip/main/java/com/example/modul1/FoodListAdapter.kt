package com.example.modul1

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class FoodListAdapter(private val context: Context, private val presenter: MainPresenter) : BaseAdapter() {
    private var foodItems: List<FoodItem> = ArrayList()

    fun initList(foodItems: List<FoodItem>) {
        this.foodItems = foodItems
        notifyDataSetChanged()
    }

    override fun getCount(): Int {
        return foodItems.size
    }

    override fun getItem(position: Int): Any {
        return foodItems[position]
    }

    override fun getItemId(position: Int): Long {
        return position.toLong()
    }

    interface OnFoodItemRemovedListener {
        fun onFoodItemRemoved(position: Int)
    }

    private var onFoodItemRemovedListener: OnFoodItemRemovedListener? = null

    fun setOnFoodItemRemovedListener(listener: OnFoodItemRemovedListener) {
        this.onFoodItemRemovedListener = listener
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val foodItem = getItem(position) as FoodItem
        val foodView = FoodItemView(context)
        foodView.bind(foodItem, position, object : OnFoodItemRemovedListener {
            override fun onFoodItemRemoved(position: Int) {
                onFoodItemRemovedListener?.onFoodItemRemoved(position)
            }
        })
        return foodView
    }
}
