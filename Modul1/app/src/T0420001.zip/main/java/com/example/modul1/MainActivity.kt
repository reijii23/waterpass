package com.example.modul1

import android.os.Bundle
import androidx.activity.ComponentActivity
//import androidx.activity.compose.setContent
import android.widget.Button
import android.widget.TextView
import android.widget.ImageButton
import android.widget.LinearLayout
import com.example.modul1.ui.theme.Modul1Theme
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ListView
import java.util.LinkedList


class MainActivity : ComponentActivity(), IMainActivity {
    private val presenter = MainPresenter(this)
    private val foodItems = mutableListOf<FoodItem>()
    private val adapter = FoodListAdapter(this, presenter)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val titles = findViewById<ListView>(R.id.listView)
        titles.adapter = adapter

        val addButton = findViewById<Button>(R.id.addButton)

        addButton.setOnClickListener {
            val titleEditText = findViewById<EditText>(R.id.title)
            val detailEditText = findViewById<EditText>(R.id.detail)

            val title = titleEditText.text.toString()
            val detail = detailEditText.text.toString()

            if (title.isNotEmpty() && detail.isNotEmpty()) {
                presenter.addList(title, detail)
            }
        }

        val adapter = FoodListAdapter(this, presenter)
        adapter.setOnFoodItemRemovedListener(object : FoodListAdapter.OnFoodItemRemovedListener {
            override fun onFoodItemRemoved(position: Int) {
                presenter.deleteList(position)
            }
        })

    }

    override fun updateList(foods: List<FoodItem>) {
        adapter.initList(foods)
    }

    override fun resetAddForm() {
        val titleEditText = findViewById<EditText>(R.id.title)
        val detailEditText = findViewById<EditText>(R.id.detail)

        titleEditText.text.clear()
        detailEditText.text.clear()
    }
}
