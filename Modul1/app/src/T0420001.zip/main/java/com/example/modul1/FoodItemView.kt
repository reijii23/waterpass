package com.example.modul1

import android.content.Context
import android.util.AttributeSet
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class FoodItemView(context: Context, attrs: AttributeSet? = null) : LinearLayout(context, attrs) {
    private val titleTextView: TextView
    private val detailsTextView: TextView
    private val starImageView: ImageButton
    private val trash: ImageButton

    init {
        inflate(context, R.layout.item_list_food, this)
        orientation = HORIZONTAL

        titleTextView = findViewById(R.id.titles)
        detailsTextView = findViewById(R.id.details)
        starImageView = findViewById(R.id.star)
        trash = findViewById(R.id.trash)
    }

    fun bind(foodItem: FoodItem, position: Int, listener: FoodListAdapter.OnFoodItemRemovedListener) {
        titleTextView.text = foodItem.title
        detailsTextView.text = foodItem.details
        starImageView.setImageResource(
            if (foodItem.isFavourite) android.R.drawable.btn_star_big_on
            else android.R.drawable.btn_star_big_off
        )

        starImageView.setOnClickListener {
            foodItem.isFavourite = !foodItem.isFavourite
            starImageView.setImageResource(
                if (foodItem.isFavourite) android.R.drawable.btn_star_big_on
                else android.R.drawable.btn_star_big_off
            )
        }

        trash.setOnClickListener {
            listener.onFoodItemRemoved(position)
        }
    }
}
