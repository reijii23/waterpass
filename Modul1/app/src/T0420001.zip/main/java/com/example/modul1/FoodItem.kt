package com.example.modul1
data class FoodItem(val title: String, val details: String, var isFavourite: Boolean = false)
