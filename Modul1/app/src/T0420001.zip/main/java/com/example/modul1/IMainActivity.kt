package com.example.modul1

interface IMainActivity {
    fun updateList(foods: List<FoodItem>)
    fun resetAddForm()
}
