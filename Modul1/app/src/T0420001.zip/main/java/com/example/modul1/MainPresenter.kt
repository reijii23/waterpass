package com.example.modul1

class MainPresenter(private val ui: IMainActivity) {
    private val foods = mutableListOf<FoodItem>()

    fun loadData(foodObjectArr: Array<FoodItem>) {
        foods.clear()
        foods.addAll(foodObjectArr)
        ui.updateList(foods)
    }

    fun deleteList(position: Int) {
        if (position >= 0 && position < foods.size) {
            foods.removeAt(position)
            ui.updateList(foods)
        }
    }

    fun addList(title: String, details: String) {
        val newFoodItem = FoodItem(title, details)
        foods.add(newFoodItem)
        ui.updateList(foods)
        ui.resetAddForm()
    }

    fun toggleFav(position: Int) {
        if (position >= 0 && position < foods.size) {
            val foodItem = foods[position]
            foodItem.isFavourite = !foodItem.isFavourite
            ui.updateList(foods)
        }
    }
}
