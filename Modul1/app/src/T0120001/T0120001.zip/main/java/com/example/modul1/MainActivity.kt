package com.example.modul1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import android.widget.Button
import android.widget.TextView
import com.example.modul1.ui.theme.Modul1Theme

class MainActivity : ComponentActivity() {
    private lateinit var centerText: TextView
    private lateinit var buttonPlus: Button
    private lateinit var buttonReset: Button
    private lateinit var button1: Button
    private lateinit var button2: Button
    private lateinit var button3: Button
    private lateinit var button4: Button

    private var isAddingMode = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Modul1Theme {
                setContentView(R.layout.layouts)
                centerText = findViewById(R.id.centerText)
                buttonPlus = findViewById(R.id.buttonPlus)
                buttonReset = findViewById(R.id.buttonReset)
                button1 = findViewById(R.id.button1)
                button2 = findViewById(R.id.button2)
                button3 = findViewById(R.id.button3)
                button4 = findViewById(R.id.button4)

                buttonPlus.setOnClickListener {
                    isAddingMode = !isAddingMode
                    if (isAddingMode) {
                        buttonPlus.text = "+"
                    } else {
                        buttonPlus.text = "-"
                    }
                }
                button1.setOnClickListener {
                    val value = if (isAddingMode) 1 else -1
                    updateCenterText(value)
                }
                button2.setOnClickListener {
                    val value = if (isAddingMode) 2 else -2
                    updateCenterText(value)
                }
                button3.setOnClickListener {
                    val value = if (isAddingMode) 3 else -3
                    updateCenterText(value)
                }
                button4.setOnClickListener {
                    val value = if (isAddingMode) 4 else -4
                    updateCenterText(value)
                }
                buttonReset.setOnClickListener {
                    centerText.text = "0"
                }
            }
        }
    }
    private fun updateCenterText(value: Int) {
        val currentValue = centerText.text.toString().toInt()
        val newValue = currentValue + value
        centerText.text = newValue.toString()
    }
}
