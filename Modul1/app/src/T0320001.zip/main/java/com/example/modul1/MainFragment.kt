package com.example.modul1

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager


class MainFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_main, container, false)

        val editText = view.findViewById<EditText>(R.id.editText)
        val button = view.findViewById<Button>(R.id.button)

        button.setOnClickListener {
            val text = editText.text.toString()
            val fragmentManager = requireActivity().supportFragmentManager
            val dialogFragment = ResultDialogFragment(text)
            dialogFragment.show(fragmentManager, ResultDialogFragment.TAG)
        }
        return view
    }
}
