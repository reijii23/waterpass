package com.example.modul1
import androidx.drawerlayout.widget.DrawerLayout;
import android.os.Bundle
import androidx.activity.ComponentActivity
import android.widget.Button
import android.widget.TextView
import android.widget.ImageButton
import android.widget.LinearLayout
import com.example.modul1.ui.theme.Modul1Theme
import android.content.Context
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ListView
import androidx.appcompat.widget.Toolbar
import java.util.LinkedList
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.fragment.app.Fragment

class MainActivity : AppCompatActivity() {
    private lateinit var toolbar: androidx.appcompat.widget.Toolbar
    lateinit var drawerLayout: androidx.drawerlayout.widget.DrawerLayout
    private lateinit var gestureDetector: GestureDetector
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layouts)
        this.toolbar = findViewById(R.id.toolbar)
        this.drawerLayout = findViewById(R.id.drawer_layout)
        this.setSupportActionBar(toolbar)

        val abdt = ActionBarDrawerToggle(this, drawerLayout, toolbar, R.string.openDrawer, R.string.closeDrawer)
        drawerLayout.addDrawerListener(abdt)
        abdt.syncState()

        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.fragment_container,MainFragment())
        fragmentTransaction.commit()

        val leftFragment = LeftFragment()
        val leftFragmentTransaction = fragmentManager.beginTransaction()
        leftFragmentTransaction.replace(R.id.left_drawer, leftFragment)
        leftFragmentTransaction.commit()
        gestureDetector = GestureDetector(this, GestureListener())
    }
    fun closeApplication() {
        moveTaskToBack(true)
        finish()
    }
    fun changePage(fragment: Fragment) {
        val fragmentManager = supportFragmentManager
        val transaction = fragmentManager.beginTransaction()
        transaction.replace(R.id.fragment_container, fragment)
        transaction.addToBackStack(null)
        transaction.commit()
        drawerLayout.closeDrawers()
    }
    //nyobain swipe" dari gugel
    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        return super.onTouchEvent(event)
    }

    inner class GestureListener : GestureDetector.SimpleOnGestureListener() {
        override fun onFling(p0: MotionEvent?, p1: MotionEvent, p2: Float, p3: Float): Boolean {
            val sensitivity = 50

            if (p2 > sensitivity) {
                drawerLayout.openDrawer(GravityCompat.START)
            } else if (p2 < -sensitivity) {
                drawerLayout.openDrawer(GravityCompat.END)
            }

            return true
        }
    }



}

