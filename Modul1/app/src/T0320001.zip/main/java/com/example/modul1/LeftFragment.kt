package com.example.modul1

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button

class LeftFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_left, container, false)

        val homeButton = view.findViewById<Button>(R.id.home)
        val pg2Button = view.findViewById<Button>(R.id.pg2)
        val exitButton = view.findViewById<Button>(R.id.exit)

        homeButton.setOnClickListener {
            val fragmentManager = requireActivity().supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            fragmentTransaction.replace(R.id.fragment_container, MainFragment())
            fragmentTransaction.commit()
            (requireActivity() as MainActivity).changePage(MainFragment())
            (requireActivity() as MainActivity).drawerLayout.closeDrawers()
        }

        pg2Button.setOnClickListener {
            val fragmentManager = requireActivity().supportFragmentManager
            val fragmentTransaction = fragmentManager.beginTransaction()
            fragmentTransaction.replace(R.id.fragment_container, SecondFragment())
            fragmentTransaction.commit()
            (requireActivity() as MainActivity).changePage(SecondFragment())
            (requireActivity() as MainActivity).drawerLayout.closeDrawers()
        }


        exitButton.setOnClickListener {
            (requireActivity() as MainActivity).closeApplication()
        }


        return view
    }
}